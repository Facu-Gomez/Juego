var nombre = document.getElementById('nombre');
var edad = document.getElementById('edad')
var error = document.getElementById('error');


error.style.color = 'red';

function enviarFormulario(){
    console.log('Enviando formulario...')

    var mensajeError = [];

    if(nombre.value === null || nombre.value === ''){
        mensajeError.push('Ingresa tu nombre');
    }
    if(edad.value === null || edad.value === ''){
        mensajeError.push('Ingresa tu edad');
    }

    var instruccion = document.getElementById('instruccion')
    instruccion.style.display = 'none'
    if (mensajeError.length == 0){
        instruccion.style.display = 'block'
    }

    error.innerHTML = mensajeError.join(', ')
    return false;
}

